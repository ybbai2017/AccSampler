"""
Converts the scoring data of a frame in clip to the prioritisation data of a frame
"""

import torch


def control_score(action, l):
    """
    For frames of the same score in the same score interval, decay by 10% from the centre to both sides.
    :param action: Decision category
    :param l: index
    :return: Decay ratio
    """
    if action > l:
        res = action - l
    else:
        res = l - action
    # return 1
    return 1.0 - res * 0.1


def trans_score_rank(root1, root2, save_path):
    """
    Reads in a score dictionary and outputs a sorted dictionary.
    :param root1: Train data score dictionary
    :param root2: Test data score dictionary
    :param save_path: Storage path for sorted dictionaries
    :return: None
    """
    dicts1 = torch.load(root1, map_location='cpu')
    dicts2 = torch.load(root2, map_location='cpu')
    items = dicts1.items()
    dicts_ = {}
    for i, (name, score) in enumerate(items):
        frame = []
        idx = 1
        for j, s in enumerate(score[0]):
            length = s * 2 + 1
            for l in range(length):
                if idx + l > 63:
                    break
                res = control_score(s, l)
                frame.append([idx + l, s, score[1][j] * res])
            idx += length
        if len(frame) != 63:
            print(score[0])
            assert 0
        frame.sort(key=lambda x: x[2], reverse=True)
        frame.sort(key=lambda x: x[1])
        select = [fs[0] for fs in frame]
        dicts_[name[0]] = select

    items = dicts2.items()
    for i, (name, score) in enumerate(items):
        frame = []
        idx = 1
        for j, s in enumerate(score[0]):
            length = s * 2 + 1
            for l in range(length):
                if idx + l > 63:
                    break
                res = control_score(s, l)
                frame.append([idx + l, s, score[1][j] * res])
            idx += length
        frame.sort(key=lambda x: x[2], reverse=True)
        frame.sort(key=lambda x: x[1])
        select = [fs[0] for fs in frame]
        dicts_[name[0]] = select

    torch.save(dicts_, save_path)