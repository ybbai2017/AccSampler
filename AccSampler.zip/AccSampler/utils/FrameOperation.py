import torch
import numpy as np
import cv2
import VideoTransforms as transforms

class frame_processing():
    def __init__(self, num_station_points, process_type, modality, alpha = 0.5,
                 new_width = 512, new_height = 512):
        
        self.num_station_points = num_station_points
        self.process_type = process_type
        if process_type == "mixup":
            self.change = self.mixup_change
        '''
        if process_type == "tc_change":
            self.change = self.tc_change
        '''
        
        self.alpha = alpha
        self.new_width = new_width
        self.new_height = new_height
        self.interpolation = cv2.INTER_LINEAR
        self.resolution = [224, 168, 112, 84]

        if modality == "rgb":
            self.read_method = lambda x: cv2.imread(x)
            self.mean = [0.485, 0.456, 0.406]
            self.std = [0.229, 0.224, 0.225]
            self.scale_ratio = [1.0, 0.875, 0.75, 0.66]
    
    
    def get_transformation(self, s, is_training, order_index = None):
        r = self.resolution[s]
        
        if self.process_type == "tc_change" and order_index != None:
            mean = [self.mean[order_index]]*3
            std = [self.std[order_index]]*3
        else:
            mean = self.mean
            std = self.std
            
        if is_training:
            return transforms.Compose([
            transforms.MultiScaleCrop((r, r), scale_ratios = self.scale_ratio),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(), transforms.Normalize(mean = mean, std = std)])
                
        else:
            return transforms.Compose([transforms.Resize((r, r)),
                transforms.ToTensor(), 
                transforms.Normalize(mean = mean, std = std)])
                        
                                                    
    def readFrames(self, frame_path):
        clip = []
        for i in frame_path:
            if isinstance(i, list):
                i = i[0]
            img = self.read_method(i)
            img =cv2.resize(img, (self.new_width, self.new_height), self.interpolation)
            clip.append(img)
        input_clip = np.stack(clip)
        return input_clip
    
    def get_station_point(self, frame_list):
        '''sample some frames uniformly as station points'''
        length = len(frame_list)
        stride = length//self.num_station_points
        station_point, station_index = [], []
        trans = self.get_transformation(s = 0, is_training = False)
        counter = 0
        num_stations = self.num_station_points #if is_training else self.num_station_points//4
        for i in range(stride - 1, length, stride):
            imgs = self.readFrames(frame_list[i])
            station_point.append(trans(imgs.squeeze(0)))
            station_index.append(i)
            counter += 1
            if counter == num_stations - 1:
                imgs = self.readFrames(frame_list[-1])
                station_point.append(trans(imgs.squeeze(0)))
                station_index.append(length - 1)
                break
        return torch.stack(station_point), station_index
        
    def combine_frame(self, paths, is_training, step):
        '''combine one clip into a single frame'''
        s = len(paths)//2
        if s >= 1:
            frames = self.readFrames([paths[0], paths[-1]])
            changed_frame = self.change(frame = frames, s = s, is_training = is_training, index = step)
            return changed_frame.unsqueeze(0)
        else:
            frames = self.readFrames(paths)
            trans = self.get_transformation(s = s, is_training = is_training)
            return trans(frames.squeeze(0)).unsqueeze(0)
        
    
    def mixup_change(self, frame, s, is_training, index = None):
        '''clip mixup'''
        lam = np.random.beta(self.alpha, self.alpha)
        changed_frame = lam * frame[0, :, :, :] + (1 - lam) * frame[-1, :, :, :]
        trans = self.get_transformation(s = s, is_training = is_training)
        return trans(changed_frame)
    '''
    def tc_change(self, frame, s, is_training, index = None):
        
        order_index = index % 3
        changed_frame = np.stack([frame[0, :, :, order_index], 
                   frame[len(frame)//2, :, :, order_index], frame[-1, :, :, order_index]], axis = 2)
        trans = self.get_transformation(s = s, is_training = is_training, order_index = order_index)
        return trans(changed_frame)
    '''