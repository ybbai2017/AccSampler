"""
make dataset
"""

import torch.utils.data as data
import os
import random
import torch
import cv2


def make_dataset(root, clip_length):
    """
    Combining image sets into clip sets. The fusion strategy for this function is to combine each of
    the fire-labelled and non-fire-labelled samples; a single clip will not use both categories.
    :param root: Root of the dataset
    :param clip_length: Length of a single clip
    :return: A list of reorganised clips, each cell containing the addresses of all frames within a single clip.
    """
    Fire_root = os.path.join(root, "Fire")
    NoFire_root = os.path.join(root, "No_Fire")
    clips = []
    Fire_list = os.listdir(Fire_root)
    Fire_list.sort()
    NoFire_list = os.listdir(NoFire_root)
    NoFire_list.sort()
    clip = []
    for index, frame in enumerate(Fire_list):
        frame_path = os.path.join(Fire_root, frame)
        clip.append(frame_path)
        if (index + 1) % clip_length == 0:
            if len(clip) == clip_length:
                clips.append((clip, 0))
                clip = []
            else:
                print(index + 1, len(clip))
    clip = []
    for index, frame in enumerate(NoFire_list):
        frame_path = os.path.join(NoFire_root, frame)
        clip.append(frame_path)
        if (index + 1) % clip_length == 0:
            if len(clip) == clip_length:
                clips.append((clip, 1))
                clip = []
            else:
                print(index + 1, len(clip))
    return clips

    
class Frame_dataset(data.Dataset):
    """
    An overloaded Dataset class for reading each clip and completing data operations.
    :param root: Root of the dataset
    :param phase: Train or Test dataset
    :param modality: RGB or flow, no use in this function
    :param clip_length: Length of a single clip
    :param transform: data operations
    :return: as normal Dataset class
    """
    def __init__(self,
                 root, # Frame path
                 phase,
                 modality,
                 clip_length=1,
                 transform=None,):

        terms = "Training" if phase == "train" else "Test"
        root = os.path.join(root, terms)
        clips = make_dataset(root, clip_length) # clip (video path)
        if len(clips) == 0:
            raise(RuntimeError("Found 0 video clips in subfolders of: " + root + "\n"
                               "Check your data directory."))
        self.root = root
        self.clips = clips
        self.modality = modality
        self.transform = transform

    def __getitem__(self, index):
        frame_list, target = self.clips[index]
        clip_input = []
        for frame in frame_list:
            img = cv2.imread(frame)
            if self.transform is not None:
                img = self.transform(img)
            clip_input.append(img)
        if len(clip_input) > 1:
            clip_input = torch.stack(clip_input)
        else:
            clip_input = clip_input[0]
        return frame_list, clip_input, target

    def __len__(self):
        return len(self.clips)


def Split_num_letters(astr):
    nums, letters= "",""
    for i in astr:
        if i.isdigit():
            nums = nums+i
        elif i.isspace():
            pass
        else:
            letters = letters+i
    return nums, letters


def make_dataset2(root, clip_length, boundary):
    """
    Combining image sets into clip sets. The fusion strategy of this function is to combine all frames from
    the same video in temporal order, and the class of the combined clip is determined by the number of fire
    and no-fire tags. In general, the class of clip is with fire whenever there are fire tags.
    :param root: Root of the dataset
    :param clip_length: Length of a single clip
    :param boundary: Number of fire-tagged frames required to determine if clip is a fire category
    :return: A list of reorganised clips, each cell containing the addresses of all frames within a single clip.
    """
    Fire_root = os.path.join(root, "Fire")
    NoFire_root = os.path.join(root, "No_Fire")
    clips = []
    Fire_list = os.listdir(Fire_root)
    NoFire_list = os.listdir(NoFire_root)
    Fire_list = [(i, 0) for i in Fire_list]
    NoFire_list = [(i, 1) for i in NoFire_list]
    frame_list = Fire_list + NoFire_list
    frame_list.sort(key = lambda x: x[0])
    clip = []
    now_type = None
    count1 = 0
    count2 = 0
    summ = 0
    for index, frame in enumerate(frame_list):
        count1 += 1
        nums, letters = Split_num_letters(frame[0])
        if frame[1] == 0:
            count2 += 1
            frame_path = os.path.join(Fire_root, frame[0])
            clip.append(frame_path)
        else:
            frame_path = os.path.join(NoFire_root, frame[0])
            clip.append(frame_path)
        if index == 0:
            now_type = letters
        if letters != now_type:
            now_type = letters
            clip = []
            clip.append(frame_path)
            count1 = 1
        if (count1 % clip_length == 0) and (count1 != 0):
            if count2 >= boundary:
                ty = 0
                summ += 1
            else:
                ty = 1
            if len(clip) == clip_length:
                clips.append((clip, ty))
                clip = []
            else:
                print(index, count1, len(clip), clip_length)
                assert 0
            count2 = 0
            count1 = 0
    return clips, summ


class Frame_dataset2(data.Dataset):
    """
    An overloaded Dataset class for reading each clip and completing data operations.
    :param root: Root of the dataset
    :param phase: Train or Test dataset
    :param modality: RGB or flow, no use in this function
    :param clip_length: Length of a single clip
    :param boundary: Number of fire-tagged frames required to determine if clip is a fire category
    :param transform: data operations
    :param is_uniform_random_sampling: Whether to return clip randomly
    :return: as normal Dataset class
    """
    def __init__(self,
                 root, # Frame path
                 phase,
                 clip_length=64,
                 boundary=1,
                 transform=None,
                 is_uniform_random_sampling=False, num_segment=1):

        self.terms = "Training" if phase == "train" else "Test"
        root = os.path.join(root, self.terms)
        clips, summ = make_dataset2(root, clip_length, boundary) # clip (video path) 
        if len(clips) == 0:
            raise(RuntimeError("Found 0 video clips in subfolders of: " + root + "\n"
                               "Check your data directory."))
        self.root = root
        self.clips = clips
        self.transform = transform
        self.is_uniform_random_sampling = is_uniform_random_sampling
        self.is_uniform_sampling = True
        self.num_segment = num_segment
    
    def __getitem__(self, index):
        frame_list, target = self.clips[index]
        clip_input = []
        if self.is_uniform_random_sampling:
            #for rnn warmup
            frame_list = sorted(random.sample(frame_list, self.num_segment))
        for frame in frame_list:
            img = cv2.imread(frame)
            if self.transform is not None:
                img = self.transform(img)
            clip_input.append(img)
        
        if len(clip_input) > 1 and isinstance(clip_input[0], torch.Tensor):
            clip_input = torch.stack(clip_input)
        else:
            clip_input = clip_input[0]
        
        return frame_list, clip_input, target

    def __len__(self):
        return len(self.clips)