import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

class policy_network(nn.Module):
    def __init__(self, in_dim, action_classes, fqa):
        super(policy_network, self).__init__()
        self.action_classes = action_classes
        self.fc1 = nn.Linear(in_dim, action_classes)
        self.action_space = [1, 3, 5, 7]
        self.fqa = fqa
        self.tau = 5
        
        self.gn = nn.GroupNorm(32, in_dim)
        
    def tau_decay(self, epoch):
        self.tau = self.tau * np.exp(-0.045*epoch)
    
    def policy_score(self, dis):
        """calculate preference score"""
        score = 0
        for i in range(0, self.action_classes):
            score += dis[i]/self.action_space[i]
        return score

    def forward(self, x):  
        x = self.fc1(self.gn(x))
        #get the one-hot label of action
        gumble_dis = F.gumbel_softmax(torch.log(F.softmax(x, dim = -1)).clamp(min=1e-8), self.tau, hard = True)
        pre = gumble_dis if self.training == True else x
        action = torch.argmax(pre).item()
        if self.fqa:
            score = self.policy_score(gumble_dis.squeeze(0))
            return (action, score)
        else:
            return action