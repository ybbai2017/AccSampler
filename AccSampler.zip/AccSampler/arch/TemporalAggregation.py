import os
import sys
current_dir = os.path.abspath(os.path.dirname(__file__))
sys.path.append(current_dir)
sys.path.append("..")

import torch
import torch.nn as nn
from PolicyNetwork import policy_network 

class gru(nn.Module):
    def __init__(self, in_dim, hidden_dim, num_layers, action_classes,
                 num_classes, dp_ratio = 0.5, fqa = False):
        super(gru, self).__init__()
        self.in_dim = in_dim
        self.hidden_size = hidden_dim
        self.action_classes = action_classes
        self.num_layers = num_layers
        self.gru = nn.GRU(input_size = in_dim, hidden_size = hidden_dim,
                            num_layers = num_layers, batch_first = True)
        self.fqa = fqa
        self.policy_module = policy_network(hidden_dim + in_dim, action_classes, fqa)
        
        self.classifier = nn.Linear(hidden_dim, num_classes) 
        self.dropout = nn.Dropout(p = dp_ratio)
        
    def init_policy_para(self):
        for m in self.policy_module.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight.data)
            elif isinstance(m, nn.GroupNorm):
                nn.init.ones_(m.weight.data)

    def policy_tau_decay(self, epoch):
        self.policy_module.tau_decay(epoch)
    
    def forward(self, input, step = None, hidden = None, station_point = None,
                train_policy = False, check = False):
        if hidden is None:
            h_0 = input.data.new(
                self.num_layers, 1, self.hidden_size).fill_(0).float()
        else:
            h_0 = hidden
            
        output, hidden = self.gru(input.view(1, -1, self.in_dim), h_0)
        output = output.squeeze(0)

        if check == True:          
            output = self.dropout(output)
            video_pre = self.classifier(output)
            return video_pre
        
        elif train_policy == True:
            feature = torch.cat((output, station_point.unsqueeze(0)), dim = -1)
            res = self.policy_module(feature)
            return res, hidden

        else:
        #for rnn warmup
            output = output[-1, :]
            output = self.dropout(output)
            video_pre = self.classifier(output)
            return video_pre.unsqueeze(0)